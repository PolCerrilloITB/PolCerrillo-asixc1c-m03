import rectangles
def main():
    rectangles.dades()
main()