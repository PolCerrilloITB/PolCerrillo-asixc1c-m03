import wordCount
def main():
    wordCount.demanar_dades()
main()