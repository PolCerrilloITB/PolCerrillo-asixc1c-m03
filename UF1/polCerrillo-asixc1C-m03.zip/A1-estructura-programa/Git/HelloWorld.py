"""
Pol Cerrillo
19/09/2023
ASIXc1C M03 UF1
Exemple: HelloWorld
"""
print("Hola món")
#Fem la traducció a l'Anglès
print("Hello World")
#TODO Fer traduccons automatitzades
