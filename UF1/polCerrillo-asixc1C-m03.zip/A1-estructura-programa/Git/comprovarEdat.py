"""
Pol Cerrillo
21/09/2023
ASIXc1C M03 UF1
Descripció: Exemple dels apunts
"""

#Programa que demana l'edat i diu si ets major d'edat.
edat=int(input("Quina edat tens?"))
if edat>=18:
    print("Ets major d'edat")
else:
    print("Ets menor d'edat")
print("Programa Finalitzat")

